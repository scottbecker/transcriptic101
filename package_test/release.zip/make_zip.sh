#zip -r release.zip -x *.git* -x *.zip *
zip -r release.zip  *
