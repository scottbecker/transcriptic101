def foo():
    print('test')
